@rem Gradle Wrapper 启动脚本（gradle-wrapper.jar 已内置，开箱即用）
@echo off
setlocal

set APP_HOME=%~dp0
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if not exist "%WRAPPER_JAR%" (
    echo [Cracked Spear] Missing gradle\wrapper\gradle-wrapper.jar
    echo Please re-extract the complete archive.
    exit /b 1
)

if defined JAVA_HOME (
    set JAVA_CMD=%JAVA_HOME%\bin\java.exe
) else (
    set JAVA_CMD=java.exe
)

"%JAVA_CMD%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% ^
    "-Dorg.gradle.appname=%~nx0" ^
    -classpath "%WRAPPER_JAR%" ^
    org.gradle.wrapper.GradleWrapperMain %*

endlocal
