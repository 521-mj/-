# 发裂的长枪 v2 · Cracked Spear

**Minecraft Java 版 1.20.1 + Forge 47.x｜零前置｜完整模组源码工程**

按你的要求重做的第二版。贴图照着参考图重绘：银白破损主刃、黑红雕花枪头（带一只「眼」）、血红枪杆、米色缠布、骨刺、下方大红黑弯钩、尾部尖刺。

---

## 一、这次具体改了什么

| 你的要求 | 落地实现 |
| --- | --- |
| 模型做成图里那样 | 64×64 像素贴图，按参考图的轮廓与配色重绘（`item/handheld` 模型） |
| 配方：铁剑 / 金块 / 铁剑 | 竖向三格 `["S","G","S"]`，S=铁剑，G=金块 |
| 攻击力无限 | 属性给约 21 亿基数，命中时兜底放大到 `1e30`，**任何生物一击必杀** |
| 投掷 + 永久定住 + 飞回 | 潜行右键投掷；命中后目标永久钉在原地，长枪自动飞回原槽位 |
| 锁定 + 投掷必中 | 普通右键锁定视线内生物；投掷后每刻追踪目标坐标，不受遮挡影响 |
| 只有持枪能看见黑色脚印 | 脚印是服务端实体，客户端渲染器按「本地玩家是否持枪」过滤绘制 |
| 脚印持续 30 秒 | 600 tick 后自动消失 |
| 站在脚印上右键 → 远程秒杀 | 读取脚印绑定的生物 UUID，直接 `kill()`，不限距离 |

### 按键（重要）

- **普通右键**：锁定视线 ±37°、48 格内最近的生物；已有锁定时按一次解除
- **潜行 + 右键**：投掷长枪（有锁定则必中），命中后飞回
- **站在黑色脚印上 + 普通右键**：远程秒杀留下脚印的生物
- **OP 命令** `/crackedspear release`：解除当前维度所有「永久定住」

> 三个右键动作会互相抢键，所以做了上面这套分流：先判断潜行（投掷）→ 再判断脚下有没有脚印（秒杀）→ 最后才是锁定。锁定/秒杀有 1 秒冷却。

---

## 二、几个必须说清的实现取舍

**「无限攻击力」**
MC 的伤害是 `float`，数学上写不进真正的 ∞。做法是物品属性给 `Integer.MAX_VALUE`（约 21 亿），`LivingHurtEvent` 里再用 `Math.max(原伤害, 1e30)` 兜底，结果就是**任何生物一击必杀**，且不会溢出成 NaN。另外默认**不秒杀玩家**（只秒杀生物），避免服务器 PVP 被一击清场；想连玩家一起秒，把 `SpearEvents.java` 里那行 `if (event.getEntity() instanceof Player) return;` 注释掉即可。

**「模型做成这样」**
MC 原版物品模型是 **2D 贴图**，不是 3D 模型。这版交付的是按参考图重绘的高清像素贴图（64×64），零前置、双端通用。如果你要真正的立体模型（带倒钩的 3D 几何），有两条路：① 写自定义 `elements` 的 JSON cuboid 模型（仍是零前置，但弯钩这类曲面只能近似）；② 用 GeckoLib / 自定义 `EntityModel`（需要额外前置，就不满足零前置了）。告诉我选哪条我再补。

**「永久定住」**
状态写在实体自己的 `persistentData` 里，随存档保存，**重启游戏后仍被钉住**（每刻拉回原位 + 清零速度 + 停掉寻路）。这很霸道，所以留了 `/crackedspear release` 兜底；被钉住的生物仍可被杀死、可被 /kill。若你希望「长枪飞回就自动解除」，改 `ThrownSpearEntity#giveBack` 里加一行清理即可。

**「只有手持长枪才能看见」**
脚印实体由原版同步发给所有客户端，但每个客户端只在自己手上有长枪时才画。所以：持枪的你看得见，别人看不见，你放下枪也立刻看不见。「看见生物走动」的判定是：附近 48 格内有持枪玩家、且该生物确实在移动，每走约 0.6 格留一个脚印。

**「远程秒杀」**
按 UUID 全局查实体，不受距离、维度加载状态以外的限制；目标已死或卸载会提示「脚印的主人已经不在了」。

---

## 三、为什么仍然「兼容性高 / 零前置」

- **零 Mixin / 零 CoreMod / 零 ASM / 零自定义网络包**：不改原版类，同步全交给原版实体机制
- **零前置**：`mods.toml` 里只有 `forge` 和 `minecraft` 本体版本约束；`build.gradle` 的 `dependencies` 只有 Forge 本身
- 只注册 **1 个物品 + 1 条配方 + 2 个实体 + 1 条命令**，不注册方块/效果/Capability/配置/GUI
- 伤害用 `Math.max` 放大而非覆盖，事件优先级 `LOW`，别的模组先结算；事件被取消时自动跳过
- 客户端渲染代码用 `Dist.CLIENT` 隔离，服务端不会加载 `net.minecraft.client.*`
- 客户端矩阵类型用 `var` 承接，不写死具体实现类，减少映射版本差异带来的编译问题
- 实体类型加 `noSummon()` / `noSave()`，重启不会残留卡住的长枪或脚印
- 服务端纯逻辑，可直接放服务器

---

## 四、构建出 `.jar`（本版已做成一键）

> 📱 **没有电脑 / 不想装 JDK？** 看 **`手机云编译出jar_保姆教程.md`**：把这个 zip 原样传到 GitHub，粘贴一段配置，云端自动编译，手机直接下载 `crackedspear-2.0.0.jar`。工程已附 `.github/workflows/build.yml`；云编译走云端 Gradle，**不用管 wrapper jar、不用装任何软件**。
>
> 下面是有电脑时的本地方式。

### 环境
- **JDK 17**（1.20.1 强制，推荐 Temurin 17），把 `JAVA_HOME` 指过去
- **联网**（首次构建要下载 Gradle、Forge、Minecraft 依赖，约 3–10 分钟）
- 不需要另外安装 Gradle：`gradle-wrapper.jar` **已内置在工程里**

### 最省事：双击脚本

| 系统 | 操作 | 结果 |
| --- | --- | --- |
| Windows | 双击 `一键出jar.bat` | 自动构建并把成品复制到本目录 `发裂的长枪_v2_1.20.1.jar` |
| macOS / Linux | 终端运行 `sh 一键出jar.sh` | 同上 |

### 或手动两条命令
```bash
./gradlew build --no-daemon          # Windows: gradlew.bat build
./gradlew runClient                  # 可选：开发环境直接开游戏测
```
原始产物：`build/libs/crackedspear-2.0.0.jar`

把 jar 丢进 `mods/` 即可，客户端 / 服务端都能放。

### 网络说明
- `gradle/wrapper/gradle-wrapper.properties` 里的 Gradle 发行版默认走**国内镜像** `mirrors.cloud.tencent.com`（实测可直接下载，约 124 MB）；如需换回官方源，改成 `https\://services.gradle.org/distributions/gradle-8.1.1-bin.zip`。
- `settings.gradle` 与 `build.gradle` 同时配置了官方源与阿里云镜像，任一不可达会自动回退；云端 CI 优先走官方源。
- 如果卡在下载，把终端里的报错贴给我，我按日志调镜像。

> 注意：Forge 模组的 `.class` 必须经 ForgeGradle 的重混淆流程才能被游戏加载，所以这一步**不能用手工 javac 代替**，也不建议把源码直接塞进 jar（那样装进游戏会崩）。

---

## 五、想改数值，看这里

| 想改什么 | 文件 | 位置 |
| --- | --- | --- |
| 是否秒杀玩家 | `event/SpearEvents.java` | `onLivingHurt` 里的 Player 判断 |
| 伤害基数 | `item/CrackedSpearItem.java` | 构造里的 `Integer.MAX_VALUE` |
| 锁定距离 / 角度 | 同上 | `LOCK_RANGE` / `bestDot` |
| 投掷速度 / 追踪力度 / 超时 | `entity/ThrownSpearEntity.java` | `1.8F` / `1.9D` / `age > 200` |
| 飞回速度 | 同上 | `step = Math.min(dist, 1.4D)` |
| 脚印持续时间 | `entity/FootprintEntity.java` | `LIFETIME = 600` |
| 脚印间隔 / 可见距离 | `event/SpearEvents.java` | `FOOTPRINT_STEP_SQR` / `HOLDER_RANGE_SQR` |
| 配方 | `data/crackedspear/recipes/cracked_spear.json` | `pattern` / `key` |
| 中文文案 | `assets/crackedspear/lang/zh_cn.json` | 直接改 |
| 长枪贴图 | `textures/item/cracked_spear.png` | 替换同名 64×64 PNG |
| 脚印贴图 | `textures/entity/black_footprint.png` | 替换同名 16×16 PNG |

---

## 六、素材与许可

- 工程骨架参考 **Forge 官方 MDK 1.20.1 / 47.3.0**（JDK 17 / Gradle 8.1.1 / ForgeGradle 6.x）[citation:3][citation:4]；注册、投射物、实体渲染、事件写法按 1.20.1 官方映射与 Forge 社区文档核对 [citation:3][citation:7][citation:14][citation:27]。
- **Java 源码、64×64 长枪贴图、16×16 脚印贴图均为本工程原创**，整体 MIT 许可（见 `LICENSE`），可自由修改、打包、二次发布。
- 《神秘复苏》为佛前献花所著作品，本模组仅作非商业设定致敬，未使用小说原文；参考图仅用于配色与轮廓参考，未搬运任何第三方美术素材。

---

## 七、交付状态

- ✅ 完整工程：构建脚本、9 个 Java 类、`mods.toml`、语言文件、模型、两张原创贴图、配方、许可、文档
- ✅ **gradle-wrapper.jar 已内置**（官方 Gradle 8.1.1，62 KB），无需再执行 `gradle wrapper`
- ✅ 新增 `一键出jar.bat` / `一键出jar.sh`，双击即自动构建并复制成品
- ✅ 新增 `.github/workflows/build.yml` + `手机云编译出jar_保姆教程.md`，手机浏览器即可云端出 jar
- ✅ 所有 JSON 已语法校验，Java 结构 / 翻译键 / 资源引用已静态扫描通过
- ⚠️ **未附成品 jar**：交付环境只有 JDK 11，且 Minecraft / Forge 依赖源被网络策略拦截，无法在这里跑完 ForgeGradle。请在本地双击一键脚本生成 `发裂的长枪_v2_1.20.1.jar`。
- ⚠️ 若要换成真 3D 模型，或改按键映射（比如投掷改成左键），告诉我，我直接改。

有编译报错或崩溃日志直接贴过来，我按日志改。
