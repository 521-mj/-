#!/bin/sh
# 发裂的长枪 v2 · macOS / Linux 一键构建
set -e
cd "$(dirname "$0")"

echo "============================================"
echo "  发裂的长枪 v2  一键构建 jar"
echo "  Minecraft 1.20.1 + Forge 47.3.0"
echo "============================================"
echo "  环境要求：JDK 17（推荐 Temurin 17），联网"
echo

if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
    echo "[错误] 缺少 gradle-wrapper.jar，请重新解压完整压缩包。"
    exit 1
fi

chmod +x gradlew 2>/dev/null || true

echo "[1/2] 正在构建，首次需下载 Forge / Minecraft 依赖，约 3-10 分钟..."
./gradlew build --no-daemon

SRC=build/libs/crackedspear-2.0.0.jar
if [ ! -f "$SRC" ]; then
    echo "[错误] 未找到 $SRC"
    exit 1
fi

cp -f "$SRC" "发裂的长枪_v2_1.20.1.jar"
echo
echo "[2/2] 完成！jar 已放在本目录："
echo "      $(pwd)/发裂的长枪_v2_1.20.1.jar"
echo "      把它放进游戏目录的 mods 文件夹即可。"
