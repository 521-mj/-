# 手机 / 平板也能出 jar：GitHub 云编译保姆教程

> 全程只用**手机浏览器**，不用电脑、不用装 JDK、不用装 Gradle、不用补 `gradle-wrapper.jar`。
> 原理：把源码 zip 传到 GitHub，让 GitHub 的免费云端服务器（自带 JDK 17 + 能连 Forge 仓库）帮你跑 `gradle build`，再把编译好的 `.jar` 给你下载。

**你要准备的**
- 一个 GitHub 账号（没有就注册，只需邮箱）
- 能上网的手机浏览器
- 已下载的 `发裂的长枪_v2_1.20.1_Forge模组源码.zip`（**不要解压**，原样上传）
- 大约 10～20 分钟（首次要下载 Minecraft / Forge 依赖）

---

## 第 1 步：建一个仓库

1. 手机浏览器打开 `https://github.com`，登录。
2. 点右上角 **`+`** → **`New repository`**。
3. 填写：
   - **Repository name**：`cracked-spear-mod`（随便起，英文小写）
   - 选 **Public**（公开仓库，Actions 免费额度最充足）
   - **不要**勾 "Add a README file"（勾了也行，不影响）
4. 点最下面绿色 **`Create repository`**。

## 第 2 步：上传那个 zip（只传 1 个文件）

1. 进入刚建好的仓库，点 **`Add file`** → **`Upload files`**。
2. 在文件选择器里选 **那个 zip**（手机会从「下载」/「文件」里选）。
   - ⚠️ **不要解压**，GitHub 网页不会自动解压，我们要的就是单个 zip。
3. 页面下方 **Commit changes** 区域：
   - 说明随便填，比如 `上传源码`
   - 选 **`Commit directly to the main branch`**
4. 点绿色 **`Commit changes`**。

> 此时仓库里只有一个 zip 文件，还不会触发编译，正常。

## 第 3 步：粘贴一个配置文件（关键）

1. 回到仓库首页，点 **`Add file`** → **`Create new file`**。
2. 顶部文件名框里**完整填这一行**（斜杠也要，GitHub 会自动建文件夹）：

```
.github/workflows/build.yml
```

3. 把下面整段**一字不差**粘进大编辑框（手机长按 → 全选 → 粘贴）：

```yaml
name: 构建发裂的长枪 jar

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 45

    steps:
      - name: 1. 拉取仓库
        uses: actions/checkout@v4

      - name: 2. 解压源码 zip
        run: |
          echo "仓库里的文件："
          ls -la
          mkdir -p src_tree
          unzip -o ./*.zip -d src_tree
          WORK=$(find src_tree -name build.gradle -printf '%h\n' | head -n 1)
          echo "找到工程目录：$WORK"
          echo "WORK=$WORK" >> "$GITHUB_ENV"

      - name: 3. 安装 JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: 4. 安装 Gradle 8.1.1
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.1.1'

      - name: 5. 编译模组
        run: |
          gradle --version
          cd "$WORK"
          gradle build --no-daemon --stacktrace
          mkdir -p "$GITHUB_WORKSPACE/out"
          cp build/libs/*.jar "$GITHUB_WORKSPACE/out/"
          echo "构建产物："
          ls -lh "$GITHUB_WORKSPACE/out"

      - name: 6. 上传 jar 供下载
        uses: actions/upload-artifact@v4
        with:
          name: crackedspear-jar
          path: out/*.jar
          if-no-files-found: error
          retention-days: 30
```

4. 拉到最下面，同样选 **`Commit directly to the main branch`**，点 **`Commit changes`**。

✅ 这次提交会**自动开始编译**。

## 第 4 步：等它编完

1. 点仓库顶部 **`Actions`** 标签。
2. 会看到一条 `构建发裂的长枪 jar`：
   - 🟡 黄点 = 正在跑
   - ✅ 绿勾 = 成功
   - ❌ 红叉 = 失败（见文末「翻车了怎么办」）
3. 首次一般 **5～15 分钟**（要下载 Forge / Minecraft 依赖）。点进去能看到实时日志，滚动到最下面出现 `构建产物： crackedspear-2.0.0.jar` 就成了。
4. 页面如果一直不动，下拉刷新一下。

> 也可以随时点 **`Run workflow`**（在 Actions 左侧）手动再跑一次，不用改任何文件。

## 第 5 步：下载 jar

1. 在这条成功的运行页面，拉到最底部 **`Artifacts`** 区域。
2. 点 **`crackedspear-jar`** → 浏览器会下载一个 `crackedspear-jar.zip`。
3. 用手机文件管理器**解压**它，里面就是：

```
crackedspear-2.0.0.jar
```

⚠️ 要的是**里面那个 `.jar`**，不是外面那层 zip。别改文件名、别再压缩一次。

## 第 6 步：装进游戏（手机端也能装）

**如果你是在手机上玩 Java 版**（PojavLauncher / FoldCraft Launcher 等）：

1. 先在启动器里装好 **Minecraft 1.20.1 + Forge 47.x**，并至少启动过一次游戏（让它生成 `mods` 文件夹）。
2. 用文件管理器把 `crackedspear-2.0.0.jar` 移动到启动器的 `mods` 目录，常见路径：
   - Pojav：`Android/data/net.kdt.pojavlaunch/files/.minecraft/mods/`
   - 其它启动器：在启动器设置里找「游戏目录 / .minecraft」，进去找 `mods`
3. 彻底关掉游戏再重开，模组列表里出现 **发裂的长枪 / Cracked Spear** 就成功了。
4. 合成：工作台竖着放 **铁剑 / 金块 / 铁剑**。

**如果是电脑端**：把 jar 丢进 `游戏目录/mods/`，同样重启即可。

---

## 翻车了怎么办

| 现象 | 处理 |
| --- | --- |
| 红叉，日志里有 `Could not resolve` / `Connection timed out` | 网络抖动，点 **`Re-run all jobs`** 重跑，多试一次基本就好 |
| 红叉，`gradle: command not found` | 把第 3 步 yml 里 `setup-gradle@v4` 改成 `@v3`，重新提交 |
| 红叉，`unzip: *.zip no matches` | 说明 zip 没传成功，回第 2 步重新上传，确认仓库首页能看到那个 zip |
| Artifacts 里是空的 | 编译没产出 jar，看日志里 `构建产物` 那一步；把日志截图发我 |
| 游戏里没出现模组 | 检查 MC 是不是 **1.20.1**、Forge 是不是 **47.x**，以及 jar 是不是放进了 `mods`（不是压缩包套娃） |

---

## 为什么这样就能成

- 编译需要 **JDK 17 + Gradle 8.1.1 + 能访问 Forge Maven 仓库**，手机本地很难凑齐；GitHub 的 Ubuntu 云端机器三样全有，而且是免费的。
- 工作流里**直接用 `gradle build`**，绕开了 `gradle-wrapper.jar` 这个二进制文件——所以你完全不用补那个 jar，这也是本地构建最麻烦的一步。
- 源码 zip 里其实也附了一份同样的 `.github/workflows/build.yml`，方便以后在电脑上解压后直接推仓库；但**按本教程走，只需粘贴上面那一段**。

## 备选（不想用 GitHub 的话）

- **GitHub Codespaces / 网页版 VS Code**：本质是同一台云机器，打开终端跑 `gradle build`，适合想看日志的人。
- **安卓 Termux**：`pkg install openjdk-17` 后手动装 Gradle 再构建，能离线但要下好几个 G、手机容易发烫卡死，不推荐新手。

---

有报错直接把 **Actions 日志最后 30 行**或崩溃报告贴给我，我按日志改代码或改工作流。
