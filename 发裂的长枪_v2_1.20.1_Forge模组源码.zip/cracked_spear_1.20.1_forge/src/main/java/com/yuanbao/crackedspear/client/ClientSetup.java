package com.yuanbao.crackedspear.client;

import com.yuanbao.crackedspear.CrackedSpearMod;
import com.yuanbao.crackedspear.ModEntities;
import com.yuanbao.crackedspear.entity.ThrownSpearEntity;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 客户端专用：注册两个实体的渲染器。服务端不会加载这个类。 */
@Mod.EventBusSubscriber(modid = CrackedSpearMod.MOD_ID,
        bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    private ClientSetup() {
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FOOTPRINT.get(), FootprintRenderer::new);
        event.registerEntityRenderer(ModEntities.THROWN_SPEAR.get(),
                ctx -> new ThrownItemRenderer<ThrownSpearEntity>(ctx));
    }
}
