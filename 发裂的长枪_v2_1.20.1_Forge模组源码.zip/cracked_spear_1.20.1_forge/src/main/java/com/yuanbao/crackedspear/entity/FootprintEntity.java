package com.yuanbao.crackedspear.entity;

import com.yuanbao.crackedspear.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level().Level;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * 生物走动时留在地面的黑色脚印。
 *
 * - 服务端实体，600 tick（30 秒）后自动消失；
 * - 记录留下它的生物 UUID，供「站在脚印上右键秒杀」使用；
 * - 原版实体同步负责发到客户端，是否绘制由客户端渲染器按「本地玩家是否持枪」过滤，
 *   因此不需要自写网络包，也不会让没持枪的玩家看见。
 */
public class FootprintEntity extends Entity {

    private static final int LIFETIME = 600;

    private int age;
    private UUID trackedUuid;

    public FootprintEntity(EntityType<? extends FootprintEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public FootprintEntity(Level level, double x, double y, double z, UUID tracked) {
        this(ModEntities.FOOTPRINT.get(), level);
        this.setPos(x, y, z);
        this.trackedUuid = tracked;
    }

    public UUID getTrackedUuid() {
        return trackedUuid;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && ++age >= LIFETIME) {
            this.discard();
        }
    }

    /* ---- 让脚印像个「贴地的装饰物」：不可推动、不可选中、不可伤害 ---- */

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.age = tag.getInt("CSAge");
        if (tag.hasUUID("CSOwner")) {
            this.trackedUuid = tag.getUUID("CSOwner");
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("CSAge", this.age);
        if (this.trackedUuid != null) {
            tag.putUUID("CSOwner", this.trackedUuid);
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
