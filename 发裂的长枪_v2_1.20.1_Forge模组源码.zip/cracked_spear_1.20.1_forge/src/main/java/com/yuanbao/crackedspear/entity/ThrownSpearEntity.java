package com.yuanbao.crackedspear.entity;

import com.yuanbao.crackedspear.ModEntities;
import com.yuanbao.crackedspear.ModItems;
import com.yuanbao.crackedspear.event.SpearEvents;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level().ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level().Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * 投掷出去的长枪。
 *
 * 状态机：飞出（有锁定则每刻追踪）→ 命中/超时 → 飞回（直接插值坐标，穿过方块）
 * → 回到玩家手中（原槽位优先，背包满则掉落）。
 *
 * 用原版 ThrowableItemProjectile 的同步机制，不自定义网络包。
 */
public class ThrownSpearEntity extends ThrowableItemProjectile {

    private UUID ownerUuid;
    private UUID lockedUuid;
    private ItemStack spearStack = ItemStack.EMPTY;
    private int returnSlot = -1;
    private boolean returning;
    private int age;

    /** 实体类型工厂用的构造 */
    public ThrownSpearEntity(EntityType<? extends ThrownSpearEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    /** 玩家投掷时用的构造 */
    public ThrownSpearEntity(Player shooter, Level level, ItemStack stack, int slot, UUID locked) {
        super(ModEntities.THROWN_SPEAR.get(), shooter, level);
        this.setNoGravity(true);
        this.setOwner(shooter);
        this.ownerUuid = shooter.getUUID();
        this.lockedUuid = locked;
        this.spearStack = stack.copy();
        this.returnSlot = slot;
        this.setItem(this.spearStack);
        this.shootFromRotation(shooter, shooter.getXRot(), shooter.getYRot(), 0.0F, 1.8F, 1.0F);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.CRACKED_SPEAR.get();
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        age++;

        if (!returning) {
            // 锁定后必中：每刻把速度指向目标，不受重力 / 遮挡影响
            if (lockedUuid != null) {
                Entity target = ((ServerLevel) this.level()).getEntity(lockedUuid);
                if (target != null && target.isAlive()) {
                    Vec3 to = new Vec3(target.getX() - getX(),
                            target.getEyeY() - getY(),
                            target.getZ() - getZ());
                    double len = to.length();
                    if (len > 0.001D) {
                        this.setDeltaMovement(to.scale(1.9D / len));
                        this.hasImpulse = true;
                    }
                }
            }
            if (age > 200) {
                beginReturn();
            }
            return;
        }

        // 飞回阶段：直接插值坐标，不参与方块碰撞，保证一定能回到手里
        this.setDeltaMovement(Vec3.ZERO);
        Entity owner = ownerUuid == null ? null : ((ServerLevel) this.level()).getEntity(ownerUuid);
        if (!(owner instanceof Player player) || !player.isAlive()) {
            dropAsItem();
            return;
        }

        Vec3 to = new Vec3(player.getX() - getX(),
                player.getEyeY() - 0.2D - getY(),
                player.getZ() - getZ());
        double dist = to.length();
        if (dist < 1.2D) {
            giveBack(player);
            this.discard();
            return;
        }
        double step = Math.min(dist, 1.4D);
        this.setPos(getX() + to.x / dist * step,
                getY() + to.y / dist * step,
                getZ() + to.z / dist * step);

        if (age > 600) {
            giveBack(player);
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (this.returning) {
            return;
        }
        super.onHitEntity(result);
        Entity hit = result.getEntity();
        if (!this.level().isClientSide && hit instanceof LivingEntity living && !(hit instanceof Player)) {
            SpearEvents.pin(living);
        }
        if (!this.level().isClientSide) {
            beginReturn();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (this.returning) {
            return;
        }
        super.onHitBlock(result);
        if (!this.level().isClientSide) {
            beginReturn();
        }
    }

    private void beginReturn() {
        if (this.returning) {
            return;
        }
        this.returning = true;
        this.lockedUuid = null;
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
    }

    private void giveBack(Player player) {
        ItemStack give = this.spearStack.isEmpty()
                ? new ItemStack(ModItems.CRACKED_SPEAR.get())
                : this.spearStack.copy();

        if (returnSlot >= 0
                && returnSlot < player.getInventory().getContainerSize()
                && player.getInventory().getItem(returnSlot).isEmpty()) {
            player.getInventory().setItem(returnSlot, give);
        } else if (!player.getInventory().add(give)) {
            player.drop(give, false);
        }
    }

    private void dropAsItem() {
        ItemStack give = this.spearStack.isEmpty()
                ? new ItemStack(ModItems.CRACKED_SPEAR.get())
                : this.spearStack.copy();
        this.level().addFreshEntity(new ItemEntity(this.level(), getX(), getY(), getZ(), give));
        this.discard();
    }
}
