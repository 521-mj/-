package com.yuanbao.crackedspear.event;

import com.yuanbao.crackedspear.CrackedSpearMod;
import com.yuanbao.crackedspear.ModItems;
import com.yuanbao.crackedspear.entity.FootprintEntity;
import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level().ServerLevel;
import net.minecraft.server.level().ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level().Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * v2 全部玩法逻辑：无限伤害、永久定住、脚印生成与维持、解除命令。
 *
 * 兼容性要点：
 * - 只用 Forge 公共事件，无 Mixin / 无 CoreMod / 无自定义网络包；
 * - 伤害用 Math.max 放大而不是覆盖，优先级 LOW，别的模组先结算；
 * - 定住状态写实体 persistentData（随实体存档保存），重启后依然有效；
 * - 脚印只在「附近有持枪玩家」时生成，避免空世界无谓开销。
 */
@Mod.EventBusSubscriber(modid = CrackedSpearMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SpearEvents {

    /** 定住标记，写在实体 persistentData 里 */
    private static final String PIN_KEY = "crackedspear:Pinned";
    private static final String PIN_X = "crackedspear:PinX";
    private static final String PIN_Y = "crackedspear:PinY";
    private static final String PIN_Z = "crackedspear:PinZ";
    private static final String LAST_X = "crackedspear:LastFootX";
    private static final String LAST_Z = "crackedspear:LastFootZ";

    /** 生物每走约 0.6 格留一个脚印 */
    private static final double FOOTPRINT_STEP_SQR = 0.36D;
    /** 持枪玩家距离超过这个值就不生成脚印 */
    private static final double HOLDER_RANGE_SQR = 48.0D * 48.0D;

    private SpearEvents() {
    }

    /* ---------------- 永久定住 ---------------- */

    public static void pin(LivingEntity entity) {
        CompoundTag tag = entity.getPersistentData();
        tag.putBoolean(PIN_KEY, true);
        tag.putDouble(PIN_X, entity.getX());
        tag.putDouble(PIN_Y, entity.getY());
        tag.putDouble(PIN_Z, entity.getZ());
        entity.setDeltaMovement(Vec3.ZERO);
    }

    public static void unpin(LivingEntity entity) {
        CompoundTag tag = entity.getPersistentData();
        tag.remove(PIN_KEY);
        tag.remove(PIN_X);
        tag.remove(PIN_Y);
        tag.remove(PIN_Z);
    }

    public static boolean isPinned(LivingEntity entity) {
        return entity.getPersistentData().getBoolean(PIN_KEY);
    }

    /* ---------------- 无限攻击力 ---------------- */

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onLivingHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();
        if (!(source.getDirectEntity() instanceof ServerPlayer attacker)) {
            return;
        }
        if (attacker.getMainHandItem().getItem() != ModItems.CRACKED_SPEAR.get()) {
            return;
        }
        // 只秒杀生物；玩家之间保留原伤害，避免服务器 PVP 被一击清场
        // （想连玩家一起秒杀，把下面这行注释掉即可）
        if (event.getEntity() instanceof Player) {
            return;
        }
        event.setAmount(Math.max(event.getAmount(), 1.0E30F));
    }

    /* ---------------- 每刻：维持定住 + 生成脚印 ---------------- */

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        Level level = entity.level();
        if (level.isClientSide) {
            return;
        }

        // 被钉住：每刻拉回原位、清零速度、停掉寻路，直到死亡或被 /crackedspear release 解除
        if (isPinned(entity)) {
            CompoundTag tag = entity.getPersistentData();
            entity.setPos(tag.getDouble(PIN_X), tag.getDouble(PIN_Y), tag.getDouble(PIN_Z));
            entity.setDeltaMovement(Vec3.ZERO);
            if (entity instanceof Mob mob) {
                mob.getNavigation().stop();
            }
            return;
        }

        // 脚印只由非玩家生物走动产生
        if (entity instanceof Player) {
            return;
        }
        Vec3 motion = entity.getDeltaMovement();
        if (motion.x * motion.x + motion.z * motion.z < 0.0004D) {
            return;
        }
        if (!anyHolderNearby(level, entity)) {
            return;
        }

        CompoundTag tag = entity.getPersistentData();
        double dx = entity.getX() - tag.getDouble(LAST_X);
        double dz = entity.getZ() - tag.getDouble(LAST_Z);
        if (tag.contains(LAST_X) && dx * dx + dz * dz < FOOTPRINT_STEP_SQR) {
            return;
        }
        tag.putDouble(LAST_X, entity.getX());
        tag.putDouble(LAST_Z, entity.getZ());

        level.addFreshEntity(new FootprintEntity(level,
                entity.getX(), entity.getY() + 0.02D, entity.getZ(), entity.getUUID()));
    }

    private static boolean anyHolderNearby(Level level, Entity source) {
        for (Player p : level.players()) {
            if (p.isAlive()
                    && (p.getMainHandItem().getItem() == ModItems.CRACKED_SPEAR.get()
                    || p.getOffhandItem().getItem() == ModItems.CRACKED_SPEAR.get())
                    && p.distanceToSqr(source) < HOLDER_RANGE_SQR) {
                return true;
            }
        }
        return false;
    }

    /* ---------------- 解除定住的命令 ---------------- */

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("crackedspear")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("release").executes(ctx -> {
                            ServerLevel level = ctx.getSource().getLevel();
                            int released = 0;
                            for (Entity e : level.getAllEntities()) {
                                if (e instanceof LivingEntity living && isPinned(living)) {
                                    unpin(living);
                                    released++;
                                }
                            }
                            ctx.getSource().sendSuccess(
                                    () -> Component.translatable("command.crackedspear.v2.release", released),
                                    true);
                            return released;
                        }))
        );
    }
}
