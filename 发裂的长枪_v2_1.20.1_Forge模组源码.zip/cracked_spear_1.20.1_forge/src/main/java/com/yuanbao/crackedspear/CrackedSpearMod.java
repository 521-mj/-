package com.yuanbao.crackedspear;

import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * 发裂的长枪 —— 独立 Forge 1.20.1 模组入口（v2）。
 *
 * 兼容性：主类只把物品 / 实体注册器挂到 MOD 事件总线。
 * 玩法全部走 Forge 公共事件 + 原版实体同步，不写 Mixin、不注册网络包。
 */
@Mod(CrackedSpearMod.MOD_ID)
public class CrackedSpearMod {

    public static final String MOD_ID = "crackedspear";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CrackedSpearMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
    }
}
