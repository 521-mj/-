package com.yuanbao.crackedspear.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.yuanbao.crackedspear.CrackedSpearMod;
import com.yuanbao.crackedspear.ModItems;
import com.yuanbao.crackedspear.entity.FootprintEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * 脚印渲染器：只有本地玩家手里拿着发裂的长枪时才绘制。
 *
 * 这正对应「只有手持长枪才能看见脚印」——实体本身由原版同步发给所有客户端，
 * 但每个客户端按自己的持枪状态决定画不画，无需任何自定义网络包。
 */
public class FootprintRenderer extends EntityRenderer<FootprintEntity> {

    private static final ResourceLocation TEX =
            new ResourceLocation(CrackedSpearMod.MOD_ID, "textures/entity/black_footprint.png");

    public FootprintRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(FootprintEntity entity) {
        return TEX;
    }

    @Override
    public void render(FootprintEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        Player local = Minecraft.getInstance().player;
        if (local == null) {
            return;
        }
        ItemStack main = local.getMainHandItem();
        ItemStack off = local.getOffhandItem();
        if (main.getItem() != ModItems.CRACKED_SPEAR.get()
                && off.getItem() != ModItems.CRACKED_SPEAR.get()) {
            return;
        }

        poseStack.pushPose();
        poseStack.translate(0.0D, 0.02D, 0.0D);

        // 用 var 承接矩阵，避免把具体矩阵实现类写死在导入里
        var pose = poseStack.last();
        var matrix = pose.pose();
        var normal = pose.normal();
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(TEX));

        float s = 0.30F;
        consumer.vertex(matrix, -s, 0.0F, -s).color(255, 255, 255, 235).uv(0.0F, 0.0F)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight).normal(normal, 0, 1, 0).endVertex();
        consumer.vertex(matrix, -s, 0.0F, s).color(255, 255, 255, 235).uv(0.0F, 1.0F)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight).normal(normal, 0, 1, 0).endVertex();
        consumer.vertex(matrix, s, 0.0F, s).color(255, 255, 255, 235).uv(1.0F, 1.0F)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight).normal(normal, 0, 1, 0).endVertex();
        consumer.vertex(matrix, s, 0.0F, -s).color(255, 255, 255, 235).uv(1.0F, 0.0F)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight).normal(normal, 0, 1, 0).endVertex();

        poseStack.popPose();
    }
}
