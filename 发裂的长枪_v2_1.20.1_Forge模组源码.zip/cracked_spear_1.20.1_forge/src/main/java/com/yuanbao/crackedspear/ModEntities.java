package com.yuanbao.crackedspear;

import com.yuanbao.crackedspear.entity.FootprintEntity;
import com.yuanbao.crackedspear.entity.ThrownSpearEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 两个实体：投掷出去的长枪、地面黑色脚印。均由原版实体同步机制负责同步，无需自写网络包。 */
public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CrackedSpearMod.MOD_ID);

    public static final RegistryObject<EntityType<ThrownSpearEntity>> THROWN_SPEAR =
            ENTITIES.register("thrown_spear", () ->
                    EntityType.Builder.<ThrownSpearEntity>of(ThrownSpearEntity::new, MobCategory.MISC)
                            .sized(0.5F, 0.5F)
                            .clientTrackingRange(8)
                            .updateInterval(2)
                            .noSummon()
                            .noSave()
                            .build("thrown_spear"));

    public static final RegistryObject<EntityType<FootprintEntity>> FOOTPRINT =
            ENTITIES.register("footprint", () ->
                    EntityType.Builder.<FootprintEntity>of(FootprintEntity::new, MobCategory.MISC)
                            .sized(0.5F, 0.02F)
                            .clientTrackingRange(16)
                            .updateInterval(20)
                            .noSummon()
                            .noSave()
                            .build("footprint"));

    private ModEntities() {
    }
}
