package com.yuanbao.crackedspear;

import com.yuanbao.crackedspear.item.CrackedSpearItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 只注册 1 个物品，保持命名空间干净。 */
public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CrackedSpearMod.MOD_ID);

    public static final RegistryObject<Item> CRACKED_SPEAR =
            ITEMS.register("cracked_spear", CrackedSpearItem::new);

    private ModItems() {
    }
}
