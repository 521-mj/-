package com.yuanbao.crackedspear.item;

import com.yuanbao.crackedspear.ModEntities;
import com.yuanbao.crackedspear.ModItems;
import com.yuanbao.crackedspear.entity.FootprintEntity;
import com.yuanbao.crackedspear.entity.ThrownSpearEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;

/**
 * 发裂的长枪 v2。
 *
 * 按键约定（写进 tooltip）：
 * - 普通右键：锁定视线内的生物；已有锁定时再按一次解除
 * - 潜行 + 右键：投掷长枪（有锁定则追踪必中），命中永久定住后自动飞回
 * - 站在黑色脚印上右键：远程秒杀留下脚印的生物
 *
 * 实现取舍：
 * - 继承原版 SwordItem，附魔 / 属性 / 挥击全交给原版，不手写属性映射表；
 * - 锁定目标只写 ItemStack NBT，不占玩家数据、不用 Capability；
 * - 不引用任何客户端专属类，服务端可直接放。
 */
public class CrackedSpearItem extends SwordItem {

    public static final String TAG_LOCKED = "LockedTarget";
    private static final double LOCK_RANGE = 48.0D;
    private static final double FOOTPRINT_RADIUS = 1.25D;

    public CrackedSpearItem() {
        // MC 的伤害是 float，无法写入真正的「无限」；这里给一个极大基数（约 21 亿），
        // 并在 LivingHurtEvent 里兜底成 1e30，最终表现为「任何生物一击必杀」。
        super(Tiers.NETHERITE, Integer.MAX_VALUE, -2.8F,
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    }

    /* ---------------- 锁定 ---------------- */

    public static UUID getLockedUUID(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.hasUUID(TAG_LOCKED) ? tag.getUUID(TAG_LOCKED) : null;
    }

    public static void setLocked(ItemStack stack, UUID uuid) {
        stack.getOrCreateTag().putUUID(TAG_LOCKED, uuid);
    }

    public static void clearLocked(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag != null) {
            tag.remove(TAG_LOCKED);
        }
    }

    /* ---------------- 外观 ---------------- */

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("攻击力 ∞").withStyle(ChatFormatting.DARK_RED));
        tooltip.add(Component.translatable("tooltip.crackedspear.v2.line1").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.crackedspear.v2.line2").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.crackedspear.v2.line3").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.crackedspear.v2.line4").withStyle(ChatFormatting.DARK_GRAY));
        UUID locked = getLockedUUID(stack);
        if (locked != null) {
            tooltip.add(Component.translatable("tooltip.crackedspear.v2.locked", locked.toString().substring(0, 8))
                    .withStyle(ChatFormatting.RED));
        } else {
            tooltip.add(Component.translatable("tooltip.crackedspear.v2.unlocked").withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    /* ---------------- 右键总入口 ---------------- */

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // 客户端只播放使用动作，效果一律服务端结算
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        // 潜行 + 右键 = 投掷
        if (player.isCrouching()) {
            return throwSpear(level, player, hand, stack);
        }

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        // 站在黑色脚印上 = 远程秒杀
        List<FootprintEntity> prints = level.getEntitiesOfClass(
                FootprintEntity.class,
                player.getBoundingBox().inflate(FOOTPRINT_RADIUS),
                e -> e.getTrackedUuid() != null);

        if (!prints.isEmpty()) {
            FootprintEntity print = prints.get(0);
            Entity target = ((ServerLevel) level).getEntity(print.getTrackedUuid());
            print.discard();
            if (target instanceof LivingEntity living && living.isAlive() && !(living instanceof Player)) {
                living.kill();
                player.getCooldowns().addCooldown(this, 20);
                player.sendSystemMessage(Component.translatable("message.crackedspear.v2.kill"));
                return InteractionResultHolder.success(stack);
            }
            player.sendSystemMessage(Component.translatable("message.crackedspear.v2.print_gone"));
            return InteractionResultHolder.success(stack);
        }

        // 普通右键 = 锁定 / 解除
        UUID already = getLockedUUID(stack);
        if (already != null) {
            clearLocked(stack);
            player.sendSystemMessage(Component.translatable("message.crackedspear.v2.unlock"));
        } else {
            LivingEntity target = findTarget(level, player);
            if (target == null) {
                player.sendSystemMessage(Component.translatable("message.crackedspear.v2.no_target"));
                return InteractionResultHolder.fail(stack);
            }
            setLocked(stack, target.getUUID());
            player.sendSystemMessage(Component.translatable(
                    "message.crackedspear.v2.lock", target.getName().getString()));
        }

        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.success(stack);
    }

    /* ---------------- 投掷 ---------------- */

    private InteractionResultHolder<ItemStack> throwSpear(Level level, Player player,
                                                          InteractionHand hand, ItemStack stack) {
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        int slot = hand == InteractionHand.MAIN_HAND ? player.getInventory().selected : 40;
        UUID locked = getLockedUUID(stack);
        ThrownSpearEntity spear = new ThrownSpearEntity(player, level, stack, slot, locked);
        level.addFreshEntity(spear);

        // 物品离手；飞回时由投射物放回原槽位
        player.setItemInHand(hand, ItemStack.EMPTY);
        player.getCooldowns().addCooldown(this, 30);
        return InteractionResultHolder.success(ItemStack.EMPTY);
    }

    /* ---------------- 锁定目标：视线夹角最小的生物 ---------------- */

    private static LivingEntity findTarget(Level level, Player player) {
        Vec3 eye = player.getEyePosition(1.0F);
        Vec3 look = player.getLookAngle().normalize();
        AABB box = player.getBoundingBox()
                .expandTowards(look.scale(LOCK_RANGE))
                .inflate(2.0D);

        List<LivingEntity> candidates = level.getEntitiesOfClass(
                LivingEntity.class, box, e -> e != player && e.isAlive());

        LivingEntity best = null;
        double bestDot = 0.80D; // 约 ±37° 锥形范围
        for (LivingEntity e : candidates) {
            Vec3 to = e.getEyePosition().subtract(eye);
            double len = to.length();
            if (len < 0.001D || len > LOCK_RANGE) {
                continue;
            }
            double dot = to.scale(1.0D / len).dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }
}
