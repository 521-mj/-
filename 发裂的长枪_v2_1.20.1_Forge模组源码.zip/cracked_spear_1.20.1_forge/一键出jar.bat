@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================
echo   发裂的长枪 v2  一键构建 jar
echo   Minecraft 1.20.1 + Forge 47.3.0
echo ============================================
echo.
echo   环境要求：JDK 17（推荐 Temurin 17），联网
echo.

if not exist "gradle\wrapper\gradle-wrapper.jar" (
    echo [错误] 缺少 gradle-wrapper.jar，请重新解压完整压缩包。
    goto :fail
)

echo [1/2] 正在构建，首次需下载 Forge / Minecraft 依赖，约 3-10 分钟...
echo.
call gradlew.bat build --no-daemon
if errorlevel 1 goto :fail

set "SRC=build\libs\crackedspear-2.0.0.jar"
if not exist "%SRC%" (
    echo [错误] 未找到 %SRC%
    goto :fail
)

copy /Y "%SRC%" "发裂的长枪_v2_1.20.1.jar" >nul
echo.
echo [2/2] 完成！jar 已放在本目录：
echo       %~dp0发裂的长枪_v2_1.20.1.jar
echo.
echo       把它放进游戏目录的 mods 文件夹即可（客户端 / 服务端都能放）。
echo.
pause
exit /b 0

:fail
echo.
echo [失败] 构建未完成。把上面的报错日志复制给我，我按日志改。
pause
exit /b 1
